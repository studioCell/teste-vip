
import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateCaption = async (
  model: string,
  price: number,
  condition: string,
  brand: string,
  memory: string,
  theme: string,
  storeName: string
): Promise<string> => {
  try {
    // Mapeamento de temas para texto descritivo da campanha
    let themeText = 'Oferta Especial';
    
    switch (theme) {
      case 'padrao': themeText = 'Black Friday'; break;
      case 'natal': themeText = 'Natal e Fim de Ano'; break;
      case 'maes': themeText = 'Dia das Mães'; break;
      case 'namorados': themeText = 'Dia dos Namorados'; break;
      case 'pais': themeText = 'Dia dos Pais'; break;
      case 'consumidor': themeText = 'Semana do Consumidor'; break;
      case 'criancas': themeText = 'Dia das Crianças'; break;
      case 'saldao': themeText = 'Saldão de Fim de Mês'; break;
      case 'queima': themeText = 'Queima de Estoque Total'; break;
      case 'melhores': themeText = 'Seleção dos Melhores Produtos'; break;
      case 'verao': themeText = 'Ofertas de Verão'; break;
      // Temas Estilísticos (sem data comemorativa específica)
      case 'white':
      case 'colorful':
      case 'sky':
      case 'tech':
      case 'roxo':
        themeText = 'Promoção Exclusiva da Loja'; 
        break;
      default: themeText = 'Oferta Imperdível';
    }
    
    const prompt = `
      Aja como um especialista em Copywriting para Instagram Stories.
      Crie UMA ÚNICA opção de legenda curta, emocionante e altamente persuasiva para vender este produto.

      📦 Dados da Oferta:
      - Loja: ${storeName}
      - Produto: ${brand} ${model}
      - Especificação/Memória: ${memory}
      - Valor: R$ ${price}
      - Condição de Pagamento: ${condition}
      - Tema da Campanha/Data Comemorativa: ${themeText}

      Requisitos Obrigatórios:
      1. O TEXTO DEVE SER FOCADO NO TEMA: "${themeText}". Use vocabulário e contexto desta data/tema.
      2. Intercale as informações do produto de forma natural.
      3. Use emojis chamativos relacionados EXCLUSIVAMENTE ao tema "${themeText}" (ex: 🎄 para Natal, 💘 para Namorados, 🔥 para Queima, etc).
      4. Crie senso de urgência.
      5. Máximo de 3 a 4 linhas curtas.
      
      Gere apenas o texto da legenda, sem aspas e sem introduções.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });

    return response.text || "Confira essa oferta imperdível na nossa loja! 🚀";
  } catch (error) {
    console.error("Error generating caption:", error);
    return "Erro ao gerar legenda. Tente novamente.";
  }
};

export const generateSpecs = async (
  model: string,
  memory: string,
  brand?: string
): Promise<string> => {
  try {
    const productQuery = brand ? `${brand} ${model}` : model;
    
    // Select specific prompt logic based on category/brand
    let categoryContext = "eletrônicos como smartphones";
    let specsList = `
      💾 Armazenamento/RAM: ${memory}
      🧠 Processador: [Nome do Chipset/CPU]
      📸 Câmera: [Specs Principais]
      📱 Tela: [Tamanho e Tecnologia]
      🔋 Bateria: [mAh]
      📡 Conectividade: [5G/NFC]
      👆 Biometria: [Tipo]
    `;

    if (brand === 'games') {
      categoryContext = "consoles de videogame";
      specsList = `
      💾 Armazenamento: ${memory}
      🎮 Resolução Máx: [4K/8K]
      🚀 Taxa de Quadros: [FPS alvo]
      💿 Mídia: [Física/Digital]
      🕹️ Controle: [Modelo Incluso]
      📡 Conectividade: [WiFi/Bluetooth]
      `;
    } else if (brand === 'jbl' || brand === 'airpods' || brand === 'acessorios') {
      categoryContext = "equipamentos de áudio e acessórios";
      specsList = `
      🔋 Bateria: [Duração em Horas]
      💧 Resistência: [IPX Rating]
      🔊 Potência/Som: [Watts/Tecnologia]
      📡 Conexão: [Bluetooth Versão]
      🔌 Carregamento: [Tipo de entrada]
      🎨 Cor/Modelo: ${memory}
      `;
    } else if (brand === 'applewatch' || brand === 'acessorios' && model.includes('Watch')) {
      categoryContext = "smartwatches";
      specsList = `
      📏 Tamanho: ${memory}
      📱 Tela: [Tipo/Brilho]
      🔋 Bateria: [Duração]
      ❤️ Sensores: [Saúde/Esportes]
      💧 Resistência: [Metros/IP]
      📡 Conectividade: [GPS/Cellular]
      `;
    } else if (brand === 'perfumes') {
      categoryContext = "perfumes importados";
      specsList = `
      🧪 Volume: ${memory}
      👃 Família Olfativa: [Ex: Amadeirado, Floral]
      ⏳ Fixação: [Estimativa]
      🌟 Notas de Topo: [Principais]
      💼 Ocasião: [Dia/Noite/Festa]
      `;
    } else if (brand === 'drones') {
      categoryContext = "drones profissionais e amadores";
      specsList = `
      📦 Combo/Versão: ${memory}
      📷 Câmera: [Resolução Vídeo/Foto]
      ✈️ Tempo de Voo: [Minutos]
      📡 Alcance: [Km]
      ⚖️ Peso: [Gramas]
      🛡️ Sensores: [Obstáculos]
      `;
    }

    const prompt = `
      Pesquise as especificações técnicas exatas do produto "${productQuery}" (${categoryContext}) preferencialmente no site tudocelular.com, techtudo, ou site oficial da fabricante.
      
      Com base nos dados encontrados, monte uma ficha técnica resumida APENAS com os itens abaixo, usando emojis e sendo muito direto.
      
      IMPORTANTE: Para o campo de memória/variante, USE EXATAMENTE o valor: "${memory}".

      Lista a ser gerada:
      ${specsList}

      Se não encontrar algum dado específico, não invente, apenas omita a linha.
      Não adicione introdução, nem conclusão, nem fontes no texto final. Apenas a lista formatada.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        tools: [{ googleSearch: {} }], // Ativa a busca no Google para dados reais
      }
    });

    return response.text || "Especificações indisponíveis no momento.";
  } catch (error) {
    console.error("Error generating specs:", error);
    return "Erro ao gerar ficha técnica. Verifique sua conexão.";
  }
};
